let users = [{
    id: 1,
    name: 'Tamas',
    cars: [1, 2]
  }, {
    id: 2,
    name: 'Susan',
    cars: []
  }, {
    id: 3,
    name: 'Steven',
    cars: [3]
  }];
  
  let cars = [{
    id: 1,
    make: 'Ford',
    model: 'Focus',
    colour: 'red',
    ownedBy: 1
  }, {
    id: 2,
    make: 'Fiat',
    model: '500',
    colour: 'blue',
    ownedBy: 1
  }, {
    id: 3,
    make: 'Mercedes',
    model: 'C250',
    colour: 'silver',
    ownedBy: 3
  }];

  let gfxtrans = [{
    event: 'NEW',
    subEvent: 'NEW',
    sourceSystem: 'TARSAN_AUTO_EFX',
    timestamp: '2020-03-30T01:52:06',
    Trade: {
      tradeDate: '2020-03-30',
      entryDate: '2020-03-30',
      bookingLocation: 'NY',
      tradeType: 'Spot',
      buySell: 'CSFB Sell',
      isElectrnonicallyConfirmed:  'false',
      Note: [{
          note: 'USD',
          noteType: 'CURRENCY_ENTERED',
        }, {
          note: 'COMMENT',
          noteType: 'HELLO SNKD',
        }],
      Party: [{
          partyType: 'Broker',
          id: [{
            id: 'AES',
            idType: 'NAME',
            source: 'TEST SOURCE',
          }]
        }],
      Customer: [{
          id: 'ALFA',
          idType: 'DISPLAYID',
          source: 'CustomerService',
        }, {
          id: 'H1234',
          idType: 'CUST_NUMBER',
          source: 'CustomerService',
        }],
      PrimeBrokerage: 
      {
        f1: '1122',
      },
      ReportConfirmation: {
        f1: '1122',
      },
      ReportConfirmationDetail: {
        f1: '1122',
      },
      TradeId: [{
            id: 'EFX1212121',
            idType: 'EFX_DEAL_ID',
            source: 'EFX',
          }, {
            id: '12343434',
            idType: 'RUETERS_DEAL_ID',
            source: 'EFX',
          }],
      Fx: {
        baseCurrency: 'USD',
        counterCurrency: 'JPY',
        rate: 1.234,
        currencyAmount: 11102.02,
        counterAmount: 2323232.33,
        spotDate: '2020-01-01',
        Payment: [{
            amount: 121212.2,
            currency: 'USD',
            paymentDate: '2020-01-01',
            paymentDirection: 'CSFB Sell',
            AlternatePayment: {
              amount: 2232323.22,
              currency: 'USD',
            }
          }, {
            amount: 34343121212.2,
            currency: 'JPY',
            paymentDate: '2020-01-01',
            paymentDirection: 'CSFB Buy',
            AlternatePayment: {
              amount: 2232323.22,
              currency: 'USD',
            }
          }],
        BaseFX: {
          f1: '1122',
        }
      }, 
      MarkerRate: [{
          f1: '1111',
        }, {
          f1: '2322',
        }], 
      Booking: [{
          bookType: 'Area',
          name: 'AES',
        }, {
          bookType: 'LegalEntity',
          name: 'LONDON BR',
        },
      ], 
      Valuation: {
        delta: 12121.33,
        vega: 3343434.33,
        gamma: 33434.00,
      }, 
      executionDetail: {
        excecutionEvent: {
          id: '111',
          idType: 'ssddsdds',
          source: 'AGORA',
          event: [{
            name: 'somevent',
            timestamp: '22222',
            value: '',
            }]
        }
      },
      taxonomyDetails: {
        f1: '121212',
      }
    }
  }];
  
  module.exports = {
    users,
    cars,
    gfxtrans
  };