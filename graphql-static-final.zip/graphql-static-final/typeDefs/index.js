const userSchema = require('./user');
const carSchema = require('./car');
const gfxSchema= require('./ds')

const defaultSchema = require('./default');

module.exports = [defaultSchema, userSchema, carSchema, gfxSchema];