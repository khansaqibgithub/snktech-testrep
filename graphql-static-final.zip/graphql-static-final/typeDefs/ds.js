const { gql } = require('apollo-server-express');
module.exports = gql`
  extend type Query {
    gfxtrans: [GFX_TRAN]
    gfxtran(id: String!): GFX_TRAN    
    msg: GFX_TRAN
  }

  type tran_primebrokerageType {
    f1: String
  }
  
  type tran_reportConfirmationType {
    f1: String
  }

  type tran_ReportConfirmationDetailType {
    f1: String
  }

  type tran_MarkerRateType {
    f1: String
  }

  type tran_BookingType {
    bookType: String!
    name: String!
  }

  type tran_ValuationType {
    delta: Float!
    vega: Float!
    gamma: Float!
  }

  type tran_executionDetailType {
    excecutionEvent: tran_executionEventType
  }

  type tran_taxonomyDetailsType {
    f1: String!
  }

  type tran_executionEventType {
    id: String!
    idType: String!
    source: String!
    event: [tran_eventType]
  }

  type tran_eventType {
    name: String!
    timestamp: String!
    value: String!
  }

  type tran_FxType {
    baseCurrency: String!
    counterCurrency: String!
    rate: Float!
    currencyAmount: Float!
    counterAmount: Float!
    spotDate: String!
    Payment: [tran_PaymentType]
    BaseFX: tran_BaseFX
  }

  type tran_BaseFX {
    f1: String
  }
  
  type tran_PaymentType {
    amount: Float!
    currency: String!
    paymentDate: String!
    paymentDirection: String!
    AlternatePayment: tran_AlternatePaymentType
  }

  type tran_AlternatePaymentType {
    amount: Float!
    currency: String!
  }


  type tran_PartyType {
    partyType: String!
    id: [tran_IdTypeSource]
  }

  type tran_NoteType {
    note: String!
    noteType: String!
  }

  type tran_IdTypeSource {
    id: String!
    idType: String!
    source: String
  }

  type tran_TradeType {
    tradeDate: String!
    entryDate: String!
    bookingLocation: String!
    tradeType: String!
    buySell: String!
    isElectrnonicallyConfirmed: String!
    Note(id: [String]): [tran_NoteType]
    Party: [tran_PartyType]
    PrimeBrokerage: tran_primebrokerageType
    ReportConfirmation: tran_reportConfirmationType
    ReportConfirmationDetail: tran_ReportConfirmationDetailType
    TradeId: [tran_IdTypeSource]
    Fx: tran_FxType
    MarkerRate: [tran_MarkerRateType]
    Booking: [tran_BookingType]
    Valuation: [tran_ValuationType]
    executionDetail: tran_executionDetailType
    taxonomyDetails: tran_taxonomyDetailsType
  }
  
  type GFX_TRAN {
    event: String!
    subEvent: String!
    sourceSystem: String!
    timestamp: String!
    Trade: tran_TradeType
}
`;