const resolvers = {
    Query: {
     gfxtrans: (parent, args , { models }) => {
      return models.gfxtrans;
     },
     gfxtran: (parent, {id}, { models }) => {
      console.log("ID1: %j", id);
      return models.gfxtrans[0]
     }
    },

    

    tran_TradeType: {
     Note: (parent, {id}, { models }) => {
    
     console.log("ID3: %j", id);
     console.log("Object: %j", parent.Note);
     return parent.Note
     }
    }
    
};
  
  module.exports = resolvers;