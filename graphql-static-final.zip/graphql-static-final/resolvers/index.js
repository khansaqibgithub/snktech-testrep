const userResolvers = require('./user');
const carResolvers = require('./car');
const gfxResolvers = require('./ds');

module.exports = [userResolvers, carResolvers,gfxResolvers];